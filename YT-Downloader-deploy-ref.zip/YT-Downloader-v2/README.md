# YT-Downloader
NCKU-SE final project.

[專案介紹](https://github.com/wadxs90123/YT-Downloader/wiki/%E5%B0%88%E6%A1%88%E4%BB%8B%E7%B4%B9)
[使用教學](https://github.com/wadxs90123/YT-Downloader/wiki/%E4%BD%BF%E7%94%A8%E6%95%99%E5%AD%B8)
[API文件](https://github.com/wadxs90123/YT-Downloader/wiki/API%E6%96%87%E4%BB%B6)

### 待更新：
- 到站人數計算 & 當前時間
- 垃圾回收
